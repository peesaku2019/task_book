<?php $__env->startSection('content'); ?>
<h1>タスク帳</h1>
<form action="/tasks" method="POST" class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="task-name" class="col-sm-3" control-label>タスク</label>
        <div class="col-sm-6">
            <input type="text" name="name" id="task-name">
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-6">
            <button type="submit" class="btn btn-default">
                <i class="fa fa-plus"></i>タスク追加
            </button>
        </div>
    </div>
</form>

<h2>やるべきこと</h2>
<table class="table table-striped task-table">
    <thead>
        <th>タスク一覧</th><th>&nbsp;</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($task->name); ?>

            </td>
            <td>
                <form action="/tasks/<?php echo e($task->id); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button>タスク削除</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>